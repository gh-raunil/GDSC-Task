function toggleMenu() 
{
    document.getElementById('navMenu').classList.toggle('show');
}